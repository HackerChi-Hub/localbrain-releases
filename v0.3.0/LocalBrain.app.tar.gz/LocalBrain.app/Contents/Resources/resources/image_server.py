#!/usr/bin/env python3
"""Minimal OpenAI-compatible image server (stdlib) backed by diffusers (Z-Image).

Endpoints:
  GET  /health                  -> 200 once the pipeline is loaded (readiness)
  POST /v1/images/generations   -> {"created":..., "data":[{"path": "..."}]}
       body: { "prompt": "...", "size": "landscape|portrait|square|wide|WxH",
               "steps": 9, "guidance": 0.0, "negative_prompt": "..." }

All machine-specific bits are CLI args, so the backend is portable: point
--diffusers-python / --model at your own install. The diffusers pipeline is
loaded ONCE in a persistent worker (the configured python) and reused.
"""
import argparse
import atexit
import json
import os
import signal
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

CFG = {}
WORKER = None
LOCK = threading.Lock()

SIZES = {
    "landscape": (768, 512),
    "portrait": (512, 768),
    "square": (512, 512),
    "wide": (1024, 512),
}

# Runs inside the diffusers python: load Z-Image once, then serve JSON lines.
WORKER_SCRIPT = r"""
import sys, json
cfg = json.loads(sys.argv[1])
import torch
from diffusers import ZImagePipeline
pipe = ZImagePipeline.from_pretrained(
    cfg["model"], torch_dtype=torch.bfloat16, low_cpu_mem_usage=False
).to("mps")
sys.stdout.write("READY\n"); sys.stdout.flush()
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    try:
        req = json.loads(line)
        kw = dict(
            width=req["width"], height=req["height"],
            num_inference_steps=req["steps"], guidance_scale=req["guidance"],
        )
        if req.get("negative_prompt"):
            kw["negative_prompt"] = req["negative_prompt"]
        img = pipe(req["prompt"], **kw).images[0]
        img.save(req["output"])
        sys.stdout.write(json.dumps({"ok": True, "path": req["output"]}) + "\n")
    except Exception as e:
        sys.stdout.write(json.dumps({"ok": False, "error": str(e)}) + "\n")
    sys.stdout.flush()
"""


def start_worker():
    global WORKER
    payload = json.dumps({"model": CFG["model"]})
    env = os.environ.copy()
    # Guard against the libomp double-init abort() that fires when a python has
    # both torch and mlx installed (two libomp copies). Prefer an isolated venv,
    # but keep this as a safety net.
    env["KMP_DUPLICATE_LIB_OK"] = "TRUE"
    proc = subprocess.Popen(
        [CFG["diffusers_python"], "-u", "-c", WORKER_SCRIPT, payload],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=sys.stderr,
        text=True,
        env=env,
    )
    # block until the pipeline reports READY (or the worker dies)
    line = proc.stdout.readline()
    if line.strip() != "READY":
        try:
            proc.kill()
        except Exception:  # noqa: BLE001
            pass
        raise RuntimeError(f"image worker failed to load (got {line!r})")
    WORKER = proc


def _stop_worker(*_args):
    """Terminate the persistent Z-Image worker so it doesn't orphan ~30GB of MPS memory."""
    global WORKER
    w = WORKER
    WORKER = None
    if w is not None and w.poll() is None:
        try:
            w.stdin.close()
        except Exception:  # noqa: BLE001
            pass
        try:
            w.terminate()
            w.wait(timeout=5)
        except Exception:  # noqa: BLE001
            try:
                w.kill()
            except Exception:  # noqa: BLE001
                pass


def generate(req):
    """Send a request to the persistent worker; auto-respawn once if it died."""
    with LOCK:
        # worker already dead (crashed since last use) → respawn
        if WORKER is None or WORKER.poll() is not None:
            start_worker()
        try:
            WORKER.stdin.write(json.dumps(req) + "\n")
            WORKER.stdin.flush()
            line = WORKER.stdout.readline()
        except (BrokenPipeError, OSError):
            line = ""
        if not line:
            # worker died mid-request → respawn and retry exactly once
            start_worker()
            WORKER.stdin.write(json.dumps(req) + "\n")
            WORKER.stdin.flush()
            line = WORKER.stdout.readline()
    if not line:
        raise RuntimeError("image worker exited (respawn failed)")
    return json.loads(line)


class Handler(BaseHTTPRequestHandler):
    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/health") or self.path.startswith("/v1/models"):
            self._json(200, {"status": "ok", "model": CFG["model"]})
        else:
            self._json(404, {"error": "not found"})

    def do_POST(self):
        if not self.path.startswith("/v1/images/generations"):
            self._json(404, {"error": "not found"})
            return
        length = int(self.headers.get("Content-Length", 0) or 0)
        raw = self.rfile.read(length) if length else b""
        try:
            data = json.loads(raw.decode("utf-8")) if raw else {}
        except json.JSONDecodeError:
            self._json(400, {"error": "invalid JSON body"})
            return
        prompt = (data.get("prompt") or "").strip()
        if not prompt:
            self._json(400, {"error": "missing 'prompt'"})
            return

        size = str(data.get("size") or "landscape")
        if "x" in size and size not in SIZES:
            try:
                w, h = (int(v) for v in size.lower().split("x"))
            except ValueError:
                w, h = SIZES["landscape"]
        else:
            w, h = SIZES.get(size, SIZES["landscape"])

        os.makedirs(CFG["out_dir"], exist_ok=True)
        out = os.path.join(CFG["out_dir"], f"img_{int(time.time() * 1000)}.png")
        # 参数转换放在 try 内：非法 steps/guidance 返回 400 而非崩连接
        try:
            steps = int(data.get("steps") or CFG["steps"])
            guidance = float(data.get("guidance", CFG["guidance"]))
        except (TypeError, ValueError):
            self._json(400, {"error": "'steps'/'guidance' must be numeric"})
            return
        req = {
            "prompt": prompt,
            "width": w,
            "height": h,
            "steps": steps,
            "guidance": guidance,
            "negative_prompt": data.get("negative_prompt") or "",
            "output": out,
        }
        try:
            res = generate(req)
        except Exception as exc:  # noqa: BLE001
            self._json(500, {"error": str(exc)})
            return
        if not res.get("ok"):
            self._json(500, {"error": res.get("error", "generation failed")})
            return
        self._json(200, {"created": int(time.time()), "data": [{"path": res["path"]}]})

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))
        sys.stderr.flush()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="Z-Image (diffusers) model dir")
    ap.add_argument("--diffusers-python", required=True, help="python with torch+diffusers")
    ap.add_argument("--steps", type=int, default=9)
    ap.add_argument("--guidance", type=float, default=0.0)
    ap.add_argument("--out-dir", default=os.path.join(tempfile.gettempdir(), "localbrain_images"))
    ap.add_argument("--port", type=int, default=11437)
    ap.add_argument("--host", default="127.0.0.1")
    a = ap.parse_args()

    CFG.update(
        {
            "model": a.model,
            "diffusers_python": a.diffusers_python,
            "steps": a.steps,
            "guidance": a.guidance,
            "out_dir": a.out_dir,
        }
    )

    sys.stderr.write(f"image_server loading model={a.model} ...\n")
    sys.stderr.flush()
    start_worker()  # blocks until pipeline ready (then /health serves 200)

    # 确保退出时回收 worker（避免 ~30GB MPS 内存孤儿进程）
    atexit.register(_stop_worker)
    signal.signal(signal.SIGTERM, _stop_worker)
    signal.signal(signal.SIGINT, _stop_worker)

    server = ThreadingHTTPServer((a.host, a.port), Handler)
    sys.stderr.write(f"image_server listening on {a.host}:{a.port}\n")
    sys.stderr.flush()
    server.serve_forever()


if __name__ == "__main__":
    main()
