#!/usr/bin/env python3
"""Protocol bridge: Responses API + Anthropic Messages API <-> Chat Completions.

`mlx_lm.server` (LocalBrain's LLM backend) only speaks OpenAI Chat Completions.
Two agentic CLIs need something else, and this single process (one port,
routed by path) translates both:

  - Codex CLI's built-in local-model support (`--oss --local-provider ollama`)
    hard-codes `WireApi::Responses` — only `POST /v1/responses`, never Chat
    Completions. Real Ollama bridges this with a ~1500-line Go module
    (`middleware/openai.go` + `openai/responses.go`); the Responses section
    below is a from-scratch Python port of that translation, verified against
    Ollama's actual source (MIT, github.com/ollama/ollama) line by line.
  - Claude Code points at `ANTHROPIC_BASE_URL`, which speaks the Anthropic
    Messages API (`POST /v1/messages`, SSE events message_start /
    content_block_start / content_block_delta / content_block_stop /
    message_delta / message_stop). The Messages section below is verified
    against litellm's production Anthropic-Messages streaming code
    (BerriAI/litellm, MIT) — not guessed from memory, since the reasoning
    from the Codex work was: exact event shape matters, third-party clients
    don't tolerate approximations.

Both translations share one fact about mlx_lm.server (verified by reading the
installed package source): it emits each tool call ALREADY COMPLETE in one
`delta.tool_calls` entry (name + full JSON-string arguments) — unlike real
OpenAI, which streams tool call arguments character-by-character across many
chunks keyed by `index`. Neither translation needs incremental tool-call
reassembly because of this. mlx_lm.server also puts reasoning/thinking text on
`delta.reasoning` (confirmed against server.py and this project's own memory
note that Gemma4 streams `delta.reasoning` before `delta.content`).

GET  /health              -> 200 {"status":"ok"}  (readiness probe)
GET  /v1/models           -> proxied straight through to the upstream mlx_lm.server
POST /v1/chat/completions -> proxied straight through (so OpenCode/ScreenLex,
                             which already speak Chat Completions, are
                             unaffected by this bridge sitting in front)
POST /v1/responses        -> translated for Codex: Responses request -> Chat
                             Completions request against upstream, then Chat
                             Completions stream/response -> Responses stream/response
POST /v1/messages         -> translated for Claude Code: Anthropic Messages
                             request -> Chat Completions request against
                             upstream, then Chat Completions stream/response
                             -> Anthropic Messages stream/response
"""

import argparse
import json
import random
import sys
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

UPSTREAM = "http://127.0.0.1:11434"  # overridden by --upstream


# ─────────────────────── Responses request -> Chat request ───────────────────────


def _content_text(content) -> str:
    """Responses `content` can be a plain string or a list of typed parts
    (input_text/output_text/input_image/input_file). We only forward text —
    mlx_lm.server is a text LLM backend, not a VLM; images belong to the
    separate Vlm backend kind, which is out of scope for this bridge."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    text = ""
    for part in content:
        ptype = part.get("type")
        if ptype in ("input_text", "output_text"):
            text += part.get("text", "")
        # input_image / input_file: silently dropped (text-only bridge).
    return text


def from_responses_request(r: dict) -> dict:
    """Port of Ollama's `FromResponsesRequest` (openai/responses.go:405-570),
    targeting plain OpenAI Chat Completions (mlx_lm.server's native format)
    instead of Ollama's internal `api.ChatRequest` struct."""
    messages = []

    instructions = r.get("instructions")
    if instructions:
        messages.append({"role": "system", "content": instructions})

    raw_input = r.get("input")
    if isinstance(raw_input, str):
        if raw_input:
            messages.append({"role": "user", "content": raw_input})
    elif isinstance(raw_input, list):
        for item in raw_input:
            itype = item.get("type") or ("message" if item.get("role") else None)

            if itype == "reasoning":
                # mlx_lm.server has no concept of replaying prior reasoning
                # back into a request (that's Chat Completions message
                # history, which only carries role/content/tool_calls) —
                # unlike Ollama's `api.Message.Thinking` field. Dropping
                # reasoning items on request conversion is the correct
                # behavior for our target, not a shortcut: there is nowhere
                # faithful to put it.
                continue

            if itype == "message":
                messages.append(
                    {"role": item.get("role", "user"), "content": _content_text(item.get("content"))}
                )
                continue

            if itype == "function_call":
                call = {
                    "id": item.get("call_id") or item.get("id") or "",
                    "type": "function",
                    "function": {
                        "name": item.get("name", ""),
                        "arguments": item.get("arguments") or "{}",
                    },
                }
                if messages and messages[-1].get("role") == "assistant":
                    messages[-1].setdefault("tool_calls", []).append(call)
                    messages[-1].setdefault("content", None)
                else:
                    messages.append({"role": "assistant", "content": None, "tool_calls": [call]})
                continue

            if itype == "function_call_output":
                output = item.get("output")
                if isinstance(output, list):
                    output = _content_text(output)
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": item.get("call_id", ""),
                        "content": output or "",
                    }
                )
                continue
            # Unknown item types are ignored rather than raising — a partial
            # conversation is far more useful to the user than a hard error
            # on every unrecognized Responses item type OpenAI might add.

    chat_req: dict = {"messages": messages}

    temperature = r.get("temperature")
    chat_req["temperature"] = temperature if temperature is not None else 1.0

    top_p = r.get("top_p")
    if top_p is not None:
        chat_req["top_p"] = top_p

    max_output_tokens = r.get("max_output_tokens")
    if max_output_tokens is not None:
        chat_req["max_tokens"] = max_output_tokens

    tools = r.get("tools") or []
    if tools:
        chat_req["tools"] = [
            {
                "type": "function",
                "function": {
                    "name": t.get("name", ""),
                    "description": t.get("description") or "",
                    "parameters": t.get("parameters") or {},
                },
            }
            for t in tools
        ]

    text_cfg = r.get("text") or {}
    fmt = (text_cfg.get("format") or {}) if isinstance(text_cfg, dict) else {}
    if fmt.get("type") == "json_schema" and fmt.get("schema"):
        chat_req["response_format"] = {
            "type": "json_schema",
            "json_schema": {"name": fmt.get("name") or "response", "schema": fmt["schema"]},
        }

    chat_req["stream"] = bool(r.get("stream"))
    if chat_req["stream"]:
        chat_req["stream_options"] = {"include_usage": True}

    return chat_req


# ─────────────────────────── Chat stream -> Responses events ───────────────────────────


class ResponsesStreamConverter:
    """Port of Ollama's `ResponsesStreamConverter` (openai/responses.go:900-1382).
    Consumes mlx_lm.server's Chat Completions streaming chunks one at a time
    via `process_chunk`, returns the list of Responses SSE events to emit for
    that chunk (usually 0-3 events; more at start/tool-call/finish)."""

    def __init__(self, response_id: str, item_id: str, model: str, request: dict):
        self.response_id = response_id
        self.item_id = item_id
        self.model = model
        self.request = request
        self.sequence_number = 0
        self.output_index = 0
        self.first_write = True
        self.content_started = False
        self.tool_calls_sent = False
        self.accumulated_text = ""
        self.accumulated_thinking = ""
        self.reasoning_item_id = None
        self.reasoning_started = False
        self.reasoning_done = False
        self.tool_call_items: list[dict] = []
        self._usage = None
        self._finished = False
        self._completed = False

    def _event(self, event_type: str, data: dict) -> dict:
        data = dict(data)
        data["type"] = event_type
        data["sequence_number"] = self.sequence_number
        self.sequence_number += 1
        return {"event": event_type, "data": data}

    def _response_object(self, status: str, output: list, usage) -> dict:
        req = self.request
        text_cfg = req.get("text") or {}
        fmt = (text_cfg.get("format") or {}) if isinstance(text_cfg, dict) else {}
        text_format = {"type": fmt.get("type", "text")}
        if fmt.get("name"):
            text_format["name"] = fmt["name"]
        if fmt.get("schema"):
            text_format["schema"] = fmt["schema"]

        reasoning_cfg = req.get("reasoning") or {}
        reasoning = None
        if reasoning_cfg.get("effort") or reasoning_cfg.get("summary"):
            reasoning = {
                "effort": reasoning_cfg.get("effort"),
                "summary": reasoning_cfg.get("summary"),
            }

        tools_out = [
            {
                "type": t.get("type", "function"),
                "name": t.get("name", ""),
                "description": t.get("description"),
                "strict": t.get("strict"),
                "parameters": t.get("parameters"),
            }
            for t in (req.get("tools") or [])
        ]

        return {
            "id": self.response_id,
            "object": "response",
            "created_at": int(time.time()),
            "completed_at": None,
            "status": status,
            "incomplete_details": None,
            "model": self.model,
            "previous_response_id": None,
            "instructions": req.get("instructions"),
            "output": output,
            "error": None,
            "tools": tools_out,
            "tool_choice": "auto",
            "truncation": req.get("truncation") or "disabled",
            "parallel_tool_calls": True,
            "text": {"format": text_format},
            "top_p": req.get("top_p", 1.0),
            "presence_penalty": 0,
            "frequency_penalty": 0,
            "top_logprobs": 0,
            "temperature": req.get("temperature", 1.0),
            "reasoning": reasoning,
            "usage": usage,
            "max_output_tokens": req.get("max_output_tokens"),
            "max_tool_calls": None,
            "store": False,
            "background": bool(req.get("background")),
            "service_tier": "default",
            "metadata": {},
            "safety_identifier": None,
            "prompt_cache_key": None,
        }

    def _created_event(self) -> dict:
        return self._event("response.created", {"response": self._response_object("in_progress", [], None)})

    def _in_progress_event(self) -> dict:
        return self._event("response.in_progress", {"response": self._response_object("in_progress", [], None)})

    def _process_thinking(self, thinking: str) -> list:
        events = []
        if not self.reasoning_started:
            self.reasoning_started = True
            self.reasoning_item_id = f"rs_{random.randint(0, 999999)}"
            events.append(
                self._event(
                    "response.output_item.added",
                    {
                        "output_index": self.output_index,
                        "item": {"id": self.reasoning_item_id, "type": "reasoning", "summary": []},
                    },
                )
            )
        self.accumulated_thinking += thinking
        events.append(
            self._event(
                "response.reasoning_summary_text.delta",
                {
                    "item_id": self.reasoning_item_id,
                    "output_index": self.output_index,
                    "summary_index": 0,
                    "delta": thinking,
                },
            )
        )
        return events

    def _finish_reasoning(self) -> list:
        if not self.reasoning_started or self.reasoning_done:
            return []
        self.reasoning_done = True
        events = [
            self._event(
                "response.reasoning_summary_text.done",
                {
                    "item_id": self.reasoning_item_id,
                    "output_index": self.output_index,
                    "summary_index": 0,
                    "text": self.accumulated_thinking,
                },
            ),
            self._event(
                "response.output_item.done",
                {
                    "output_index": self.output_index,
                    "item": {
                        "id": self.reasoning_item_id,
                        "type": "reasoning",
                        "summary": [{"type": "summary_text", "text": self.accumulated_thinking}],
                        "encrypted_content": self.accumulated_thinking,
                    },
                },
            ),
        ]
        self.output_index += 1
        return events

    def _process_tool_calls(self, tool_calls: list) -> list:
        events = list(self._finish_reasoning())
        for i, tc in enumerate(tool_calls):
            func = tc.get("function", {})
            call_id = tc.get("id") or f"call_{random.randint(0, 999999)}"
            name = func.get("name", "")
            arguments = func.get("arguments", "") or ""
            fc_item_id = f"fc_{random.randint(0, 999999)}_{i}"
            idx = self.output_index + i

            self.tool_call_items.append(
                {
                    "id": fc_item_id,
                    "type": "function_call",
                    "status": "completed",
                    "call_id": call_id,
                    "name": name,
                    "arguments": arguments,
                }
            )
            events.append(
                self._event(
                    "response.output_item.added",
                    {
                        "output_index": idx,
                        "item": {
                            "id": fc_item_id,
                            "type": "function_call",
                            "status": "in_progress",
                            "call_id": call_id,
                            "name": name,
                            "arguments": "",
                        },
                    },
                )
            )
            if arguments:
                events.append(
                    self._event(
                        "response.function_call_arguments.delta",
                        {"item_id": fc_item_id, "output_index": idx, "delta": arguments},
                    )
                )
            events.append(
                self._event(
                    "response.function_call_arguments.done",
                    {"item_id": fc_item_id, "output_index": idx, "arguments": arguments},
                )
            )
            events.append(
                self._event(
                    "response.output_item.done",
                    {
                        "output_index": idx,
                        "item": {
                            "id": fc_item_id,
                            "type": "function_call",
                            "status": "completed",
                            "call_id": call_id,
                            "name": name,
                            "arguments": arguments,
                        },
                    },
                )
            )
        return events

    def _process_text_content(self, content: str) -> list:
        events = list(self._finish_reasoning())
        if not self.content_started:
            self.content_started = True
            events.append(
                self._event(
                    "response.output_item.added",
                    {
                        "output_index": self.output_index,
                        "item": {
                            "id": self.item_id,
                            "type": "message",
                            "status": "in_progress",
                            "role": "assistant",
                            "content": [],
                        },
                    },
                )
            )
            events.append(
                self._event(
                    "response.content_part.added",
                    {
                        "item_id": self.item_id,
                        "output_index": self.output_index,
                        "content_index": 0,
                        "part": {"type": "output_text", "text": "", "annotations": [], "logprobs": []},
                    },
                )
            )
        self.accumulated_text += content
        events.append(
            self._event(
                "response.output_text.delta",
                {
                    "item_id": self.item_id,
                    "output_index": self.output_index,
                    "content_index": 0,
                    "delta": content,
                    "logprobs": [],
                },
            )
        )
        return events

    def _final_output(self) -> list:
        output = []
        if self.reasoning_started:
            output.append(
                {
                    "id": self.reasoning_item_id,
                    "type": "reasoning",
                    "summary": [{"type": "summary_text", "text": self.accumulated_thinking}],
                    "encrypted_content": self.accumulated_thinking,
                }
            )
        if self.tool_call_items:
            output.extend(self.tool_call_items)
        elif self.content_started:
            output.append(
                {
                    "id": self.item_id,
                    "type": "message",
                    "status": "completed",
                    "role": "assistant",
                    "content": [
                        {
                            "type": "output_text",
                            "text": self.accumulated_text,
                            "annotations": [],
                            "logprobs": [],
                        }
                    ],
                }
            )
        return output

    def _process_completion(self) -> list:
        events = list(self._finish_reasoning())
        if not self.tool_calls_sent and self.content_started:
            events.append(
                self._event(
                    "response.output_text.done",
                    {
                        "item_id": self.item_id,
                        "output_index": self.output_index,
                        "content_index": 0,
                        "text": self.accumulated_text,
                        "logprobs": [],
                    },
                )
            )
            events.append(
                self._event(
                    "response.content_part.done",
                    {
                        "item_id": self.item_id,
                        "output_index": self.output_index,
                        "content_index": 0,
                        "part": {
                            "type": "output_text",
                            "text": self.accumulated_text,
                            "annotations": [],
                            "logprobs": [],
                        },
                    },
                )
            )
            events.append(
                self._event(
                    "response.output_item.done",
                    {
                        "output_index": self.output_index,
                        "item": {
                            "id": self.item_id,
                            "type": "message",
                            "status": "completed",
                            "role": "assistant",
                            "content": [
                                {
                                    "type": "output_text",
                                    "text": self.accumulated_text,
                                    "annotations": [],
                                    "logprobs": [],
                                }
                            ],
                        },
                    },
                )
            )

        usage_src = self._usage or {}
        prompt_tokens = usage_src.get("prompt_tokens", 0) or 0
        completion_tokens = usage_src.get("completion_tokens", 0) or 0
        usage = {
            "input_tokens": prompt_tokens,
            "output_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
            "input_tokens_details": {"cached_tokens": 0},
            "output_tokens_details": {"reasoning_tokens": 0},
        }
        response = self._response_object("completed", self._final_output(), usage)
        response["completed_at"] = int(time.time())
        events.append(self._event("response.completed", {"response": response}))
        return events

    def process_chunk(self, chunk: dict) -> list:
        """One mlx_lm.server Chat Completions SSE chunk in, list of Responses
        SSE events out. Mirrors Ollama's `Process(r api.ChatResponse)`."""
        events = []

        # mlx_lm.server's final usage-only chunk: {"choices": [], "usage": {...}}
        if not chunk.get("choices"):
            if "usage" in chunk:
                self._usage = chunk["usage"]
            return events

        choice = chunk["choices"][0]
        delta = choice.get("delta") or {}
        finish_reason = choice.get("finish_reason")

        has_tool_calls = bool(delta.get("tool_calls"))
        has_thinking = bool(delta.get("reasoning"))
        has_content = bool(delta.get("content"))

        if self.first_write:
            self.first_write = False
            events.append(self._created_event())
            events.append(self._in_progress_event())

        if has_thinking:
            events.extend(self._process_thinking(delta["reasoning"]))

        if has_tool_calls:
            events.extend(self._process_tool_calls(delta["tool_calls"]))
            self.tool_calls_sent = True

        if not has_tool_calls and not self.tool_calls_sent and has_content:
            events.extend(self._process_text_content(delta["content"]))

        # NOT emitted here: mlx_lm.server sends the finish_reason chunk BEFORE
        # its separate usage-only chunk (verified against the installed
        # server.py source), so response.completed needs the real token counts
        # that haven't arrived yet. The caller calls `finalize()` once the SSE
        # stream actually ends (after the usage chunk / on [DONE]).
        if finish_reason is not None:
            self._finished = True

        return events

    def finalize(self) -> list:
        """Call once after the upstream SSE stream ends. Idempotent."""
        if self._completed:
            return []
        self._completed = True
        return self._process_completion()


def to_response(model: str, response_id: str, item_id: str, chat_response: dict, request: dict) -> dict:
    """Non-streaming path: one full Chat Completions response -> one full
    Responses object. Reuses the streaming converter by feeding it a single
    synthetic chunk shaped like a streaming delta, since the two converge to
    the same `_final_output`/`_response_object` machinery."""
    converter = ResponsesStreamConverter(response_id, item_id, model, request)
    choice = (chat_response.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    synthetic_chunk = {
        "choices": [
            {
                "delta": {
                    "content": message.get("content"),
                    "reasoning": message.get("reasoning"),
                    "tool_calls": message.get("tool_calls"),
                },
                "finish_reason": choice.get("finish_reason", "stop"),
            }
        ]
    }
    usage = chat_response.get("usage")
    if usage:
        converter._usage = usage
    converter.process_chunk(synthetic_chunk)
    completed = converter.finalize()
    resp = completed[-1]["data"]["response"]
    return resp


# ─────────────────────── Anthropic Messages request -> Chat request ───────────────────────


def _anthropic_content_text_and_tools(content) -> tuple:
    """Anthropic message `content` is either a plain string or a list of typed
    blocks (text / tool_use / tool_result / image). Returns (text, tool_calls,
    tool_results) — the caller assembles these into the right Chat Completions
    message shape depending on the role."""
    if isinstance(content, str):
        return content, [], []
    text = ""
    tool_calls = []
    tool_results = []
    for block in content or []:
        btype = block.get("type")
        if btype == "text":
            text += block.get("text", "")
        elif btype == "tool_use":
            tool_calls.append(
                {
                    "id": block.get("id", ""),
                    "type": "function",
                    "function": {
                        "name": block.get("name", ""),
                        "arguments": json.dumps(block.get("input", {}), ensure_ascii=False),
                    },
                }
            )
        elif btype == "tool_result":
            result_content = block.get("content", "")
            if isinstance(result_content, list):
                result_content = _content_text(
                    [{"type": "input_text" if c.get("type") == "text" else c.get("type"), "text": c.get("text", "")} for c in result_content]
                )
            tool_results.append({"tool_use_id": block.get("tool_use_id", ""), "content": result_content})
        # image blocks: dropped (text-only bridge, see from_responses_request's
        # docstring for the same call on the Responses side).
    return text, tool_calls, tool_results


def from_messages_request(r: dict) -> dict:
    """Anthropic Messages request -> Chat Completions request. Verified
    against Anthropic's public Messages API shape and litellm's production
    Anthropic-Messages code (BerriAI/litellm, MIT) for the content-block
    vocabulary (text/tool_use/tool_result/thinking)."""
    messages = []

    system = r.get("system")
    if system:
        system_text = system if isinstance(system, str) else _content_text(
            [{"type": "input_text", "text": b.get("text", "")} for b in system if isinstance(b, dict)]
        )
        if system_text:
            messages.append({"role": "system", "content": system_text})

    for msg in r.get("messages") or []:
        role = msg.get("role", "user")
        text, tool_calls, tool_results = _anthropic_content_text_and_tools(msg.get("content"))

        if role == "assistant":
            entry = {"role": "assistant", "content": text or None}
            if tool_calls:
                entry["tool_calls"] = tool_calls
            messages.append(entry)
        else:
            # A user turn can carry tool_result blocks (the reply to a
            # previous assistant tool_use) alongside/instead of text --
            # Chat Completions represents each tool result as its own
            # `role: tool` message, not embedded in the user message.
            if text:
                messages.append({"role": "user", "content": text})
            for tr in tool_results:
                messages.append({"role": "tool", "tool_call_id": tr["tool_use_id"], "content": tr["content"]})

    chat_req: dict = {"messages": messages}

    # Anthropic requires max_tokens; Chat Completions doesn't. Pass it through
    # 1:1 rather than inventing a default that could silently truncate.
    if r.get("max_tokens") is not None:
        chat_req["max_tokens"] = r["max_tokens"]

    if r.get("temperature") is not None:
        chat_req["temperature"] = r["temperature"]
    if r.get("top_p") is not None:
        chat_req["top_p"] = r["top_p"]

    tools = r.get("tools") or []
    if tools:
        chat_req["tools"] = [
            {
                "type": "function",
                "function": {
                    "name": t.get("name", ""),
                    "description": t.get("description") or "",
                    "parameters": t.get("input_schema") or {},
                },
            }
            for t in tools
        ]

    chat_req["stream"] = bool(r.get("stream"))
    if chat_req["stream"]:
        chat_req["stream_options"] = {"include_usage": True}

    return chat_req


# ─────────────────────── Chat stream -> Anthropic Messages events ───────────────────────

# Chat Completions `finish_reason` -> Anthropic `stop_reason`. Verified against
# Anthropic's public docs (end_turn/max_tokens/tool_use/stop_sequence are the
# only four values Claude Code's SDK switches on).
_STOP_REASON_MAP = {
    "stop": "end_turn",
    "length": "max_tokens",
    "tool_calls": "tool_use",
    "content_filter": "end_turn",
}


class AnthropicStreamConverter:
    """Consumes mlx_lm.server Chat Completions streaming chunks one at a time
    via `process_chunk`, returns the list of Anthropic Messages SSE events for
    that chunk. Event sequence verified against litellm's actual production
    Anthropic-Messages streaming code (`FakeAnthropicMessagesStreamIterator` /
    `agentic_streaming_iterator.py`, BerriAI/litellm, MIT): message_start ->
    (content_block_start -> content_block_delta* -> content_block_stop)* ->
    message_delta -> message_stop."""

    def __init__(self, message_id: str, model: str):
        self.message_id = message_id
        self.model = model
        self.first_write = True
        self.block_index = -1
        self.text_block_open = False
        self.tool_blocks_sent = False
        self.stop_reason = "end_turn"
        self._usage = None
        self._finished = False
        self._completed = False

    def _event(self, event_type: str, data: dict) -> dict:
        data = dict(data)
        data["type"] = event_type
        return {"event": event_type, "data": data}

    def _message_start_event(self) -> dict:
        return self._event(
            "message_start",
            {
                "message": {
                    "id": self.message_id,
                    "type": "message",
                    "role": "assistant",
                    "model": self.model,
                    "content": [],
                    "stop_reason": None,
                    "stop_sequence": None,
                    "usage": {"input_tokens": 0, "output_tokens": 0},
                }
            },
        )

    def _open_text_block(self) -> list:
        self.block_index += 1
        self.text_block_open = True
        return [
            self._event(
                "content_block_start",
                {"index": self.block_index, "content_block": {"type": "text", "text": ""}},
            )
        ]

    def _close_open_block(self) -> list:
        if self.text_block_open:
            self.text_block_open = False
            return [self._event("content_block_stop", {"index": self.block_index})]
        return []

    def _process_text_content(self, content: str) -> list:
        events = []
        if not self.text_block_open:
            events.extend(self._close_open_block())
            events.extend(self._open_text_block())
        events.append(
            self._event(
                "content_block_delta",
                {"index": self.block_index, "delta": {"type": "text_delta", "text": content}},
            )
        )
        return events

    def _process_tool_calls(self, tool_calls: list) -> list:
        events = self._close_open_block()
        for tc in tool_calls:
            func = tc.get("function", {})
            self.block_index += 1
            idx = self.block_index
            events.append(
                self._event(
                    "content_block_start",
                    {
                        "index": idx,
                        "content_block": {
                            "type": "tool_use",
                            "id": tc.get("id") or f"toolu_{random.randint(0, 999999)}",
                            "name": func.get("name", ""),
                            "input": {},
                        },
                    },
                )
            )
            arguments = func.get("arguments", "") or "{}"
            events.append(
                self._event(
                    "content_block_delta",
                    {"index": idx, "delta": {"type": "input_json_delta", "partial_json": arguments}},
                )
            )
            events.append(self._event("content_block_stop", {"index": idx}))
        self.tool_blocks_sent = True
        self.stop_reason = "tool_use"
        return events

    def process_chunk(self, chunk: dict) -> list:
        events = []
        if not chunk.get("choices"):
            if "usage" in chunk:
                self._usage = chunk["usage"]
            return events

        choice = chunk["choices"][0]
        delta = choice.get("delta") or {}
        finish_reason = choice.get("finish_reason")

        if self.first_write:
            self.first_write = False
            events.append(self._message_start_event())

        if delta.get("tool_calls"):
            events.extend(self._process_tool_calls(delta["tool_calls"]))
        elif delta.get("content"):
            events.extend(self._process_text_content(delta["content"]))

        if finish_reason is not None:
            self._finished = True
            if not self.tool_blocks_sent:
                self.stop_reason = _STOP_REASON_MAP.get(finish_reason, "end_turn")

        return events

    def finalize(self) -> list:
        """Call once after the upstream SSE stream ends (same reasoning as
        ResponsesStreamConverter.finalize: mlx_lm.server sends the usage-only
        chunk AFTER the finish_reason chunk, so real token counts aren't
        available until the stream actually ends)."""
        if self._completed:
            return []
        self._completed = True
        events = self._close_open_block()
        usage_src = self._usage or {}
        events.append(
            self._event(
                "message_delta",
                {
                    "delta": {"stop_reason": self.stop_reason, "stop_sequence": None},
                    "usage": {"output_tokens": usage_src.get("completion_tokens", 0) or 0},
                },
            )
        )
        events.append(
            self._event(
                "message_stop",
                {
                    "usage": {
                        "input_tokens": usage_src.get("prompt_tokens", 0) or 0,
                        "output_tokens": usage_src.get("completion_tokens", 0) or 0,
                    }
                },
            )
        )
        return events


def to_anthropic_response(message_id: str, model: str, chat_response: dict) -> dict:
    """Non-streaming path: one full Chat Completions response -> one full
    Anthropic Messages object."""
    choice = (chat_response.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    content = []
    if message.get("content"):
        content.append({"type": "text", "text": message["content"]})
    for tc in message.get("tool_calls") or []:
        func = tc.get("function", {})
        try:
            tool_input = json.loads(func.get("arguments") or "{}")
        except json.JSONDecodeError:
            tool_input = {}
        content.append(
            {
                "type": "tool_use",
                "id": tc.get("id") or f"toolu_{random.randint(0, 999999)}",
                "name": func.get("name", ""),
                "input": tool_input,
            }
        )
    stop_reason = "tool_use" if message.get("tool_calls") else _STOP_REASON_MAP.get(choice.get("finish_reason", "stop"), "end_turn")
    usage = chat_response.get("usage") or {}
    return {
        "id": message_id,
        "type": "message",
        "role": "assistant",
        "model": model,
        "content": content,
        "stop_reason": stop_reason,
        "stop_sequence": None,
        "usage": {
            "input_tokens": usage.get("prompt_tokens", 0) or 0,
            "output_tokens": usage.get("completion_tokens", 0) or 0,
        },
    }


# ─────────────────────────────────── HTTP layer ───────────────────────────────────


def _upstream_url(path: str) -> str:
    return UPSTREAM.rstrip("/") + path


class BridgeHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        sys.stderr.write("[responses_bridge] " + (fmt % args) + "\n")

    def end_headers(self):
        # mlx_lm.server 本身对每个响应都带 Access-Control-Allow-*（宽松到 `*`），
        # LocalBrain 自己的 Chat 页面是从 WKWebView 里发 fetch()，Content-Type
        # 是 application/json——不属于 CORS 的"简单请求"，浏览器会先发一个
        # OPTIONS 预检。这个 handler 之前没有覆盖 end_headers/do_OPTIONS，预检
        # 直接摔进 BaseHTTPRequestHandler 默认的 501，WebKit 见预检失败就直接
        # 掐掉整个请求（POST 都不会发出去），表现为 fetch() 抛出 "Load failed"、
        # 而且这一层完全看不到请求进来过——真机复现过：绕过 bridge 直连
        # mlx_lm.server（本来就带这三个头）一切正常，一接上 bridge 就必现。
        # 直接在 end_headers 里统一补，不用在每个响应分支各自加一遍。
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "*")
        self.send_header("Access-Control-Allow-Headers", "*")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        if self.path.startswith("/health"):
            body = b'{"status":"ok"}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if self.path.startswith("/v1/models"):
            self._proxy_passthrough("GET")
            return
        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        if self.path.startswith("/v1/responses"):
            self._handle_responses()
            return
        if self.path.startswith("/v1/messages"):
            self._handle_messages()
            return
        if self.path.startswith("/v1/"):
            self._proxy_passthrough("POST")
            return
        self.send_response(404)
        self.end_headers()

    def _read_json_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw or b"{}")

    def _proxy_passthrough(self, method: str):
        """Straight passthrough for endpoints OpenCode/ScreenLex/LocalBrain's own
        Chat page already use (Chat Completions, /v1/models, ...) — this bridge
        only needs to translate /v1/responses and /v1/messages, everything else
        should behave exactly as if the bridge weren't there.

        For `stream: true` requests (text/event-stream), this used to buffer the
        ENTIRE upstream response with `resp.read()` before writing anything back
        — real bug, not hypothetical: verified live that it makes LocalBrain's
        own Chat page (which always sends `stream: true` and reads via a
        ReadableStream reader) get zero bytes until generation fully finishes.
        For a large/slow model whose first token takes a while, the browser's
        fetch() eventually times out the connection from inactivity and throws
        "Load failed" — even though the request would have succeeded had any
        bytes arrived promptly. Fixed by relaying event-stream responses chunk
        by chunk as they arrive, same as the translated endpoints do.
        """
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length else None
        req = urllib.request.Request(_upstream_url(self.path), data=body, method=method)
        if body is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=600) as resp:
                content_type = resp.headers.get("Content-Type", "application/json")
                self.send_response(resp.status)
                self.send_header("Content-Type", content_type)
                if "text/event-stream" in content_type:
                    self.send_header("Cache-Control", "no-cache")
                    self.send_header("Connection", "close")
                    self.end_headers()
                    self.close_connection = True
                    while True:
                        chunk = resp.read(4096)
                        if not chunk:
                            break
                        try:
                            self.wfile.write(chunk)
                            self.wfile.flush()
                        except (BrokenPipeError, ConnectionResetError):
                            break
                else:
                    data = resp.read()
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
        except urllib.error.URLError as e:
            self._error(502, f"upstream unreachable: {e}")

    def _error(self, code: int, message: str):
        body = json.dumps({"error": {"message": message}}).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _handle_responses(self):
        try:
            req_body = self._read_json_body()
        except json.JSONDecodeError as e:
            self._error(400, f"invalid JSON body: {e}")
            return

        try:
            chat_req = from_responses_request(req_body)
        except Exception as e:  # noqa: BLE001 - surface conversion bugs to the client, don't 500-silently
            self._error(400, f"failed to convert responses request: {e}")
            return

        stream = chat_req["stream"]
        response_id = f"resp_{random.randint(0, 999999)}"
        item_id = f"msg_{random.randint(0, 999999)}"
        model = req_body.get("model", "local-model")

        upstream_req = urllib.request.Request(
            _upstream_url("/v1/chat/completions"),
            data=json.dumps(chat_req).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        if not stream:
            try:
                with urllib.request.urlopen(upstream_req, timeout=600) as resp:
                    chat_response = json.loads(resp.read())
            except urllib.error.URLError as e:
                self._error(502, f"upstream unreachable: {e}")
                return
            response = to_response(model, response_id, item_id, chat_response, req_body)
            body = json.dumps(response).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        # Streaming path. No Content-Length (unknown ahead of time) and no
        # chunked Transfer-Encoding either -- the simplest correct framing
        # for an SSE body under HTTP/1.1 is `Connection: close` plus actually
        # closing the socket when done, so the client's read loop terminates
        # on EOF instead of hanging forever waiting for more bytes on a
        # connection it still thinks is keep-alive (verified: curl hangs
        # indefinitely after the last event without this).
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True

        converter = ResponsesStreamConverter(response_id, item_id, model, req_body)
        try:
            with urllib.request.urlopen(upstream_req, timeout=600) as resp:
                for raw_line in resp:
                    line = raw_line.decode("utf-8", errors="replace").strip()
                    if not line or not line.startswith("data:"):
                        continue
                    payload = line[len("data:") :].strip()
                    if payload == "[DONE]":
                        break
                    try:
                        chunk = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    for event in converter.process_chunk(chunk):
                        self._write_event(event)
            for event in converter.finalize():
                self._write_event(event)
        except urllib.error.URLError as e:
            self._write_event({"event": "error", "data": {"message": f"upstream unreachable: {e}"}})

    def _handle_messages(self):
        try:
            req_body = self._read_json_body()
        except json.JSONDecodeError as e:
            self._error(400, f"invalid JSON body: {e}")
            return

        try:
            chat_req = from_messages_request(req_body)
        except Exception as e:  # noqa: BLE001 - surface conversion bugs to the client, don't 500-silently
            self._error(400, f"failed to convert messages request: {e}")
            return

        stream = chat_req["stream"]
        message_id = f"msg_{random.randint(0, 999999)}"
        model = req_body.get("model", "local-model")

        upstream_req = urllib.request.Request(
            _upstream_url("/v1/chat/completions"),
            data=json.dumps(chat_req).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        if not stream:
            try:
                with urllib.request.urlopen(upstream_req, timeout=600) as resp:
                    chat_response = json.loads(resp.read())
            except urllib.error.URLError as e:
                self._error(502, f"upstream unreachable: {e}")
                return
            response = to_anthropic_response(message_id, model, chat_response)
            body = json.dumps(response).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        # Same HTTP/1.1 framing reasoning as _handle_responses: no
        # Content-Length/chunked, so Connection: close + actually closing the
        # socket is what lets the client's read loop terminate on EOF.
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True

        converter = AnthropicStreamConverter(message_id, model)
        try:
            with urllib.request.urlopen(upstream_req, timeout=600) as resp:
                for raw_line in resp:
                    line = raw_line.decode("utf-8", errors="replace").strip()
                    if not line or not line.startswith("data:"):
                        continue
                    payload = line[len("data:") :].strip()
                    if payload == "[DONE]":
                        break
                    try:
                        chunk = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    for event in converter.process_chunk(chunk):
                        self._write_event(event)
            for event in converter.finalize():
                self._write_event(event)
        except urllib.error.URLError as e:
            self._write_event({"event": "error", "data": {"message": f"upstream unreachable: {e}"}})

    def _write_event(self, event: dict):
        data = json.dumps(event["data"])
        try:
            self.wfile.write(f"event: {event['event']}\ndata: {data}\n\n".encode())
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass


class ReusableThreadingHTTPServer(ThreadingHTTPServer):
    # A just-killed previous instance of this same bridge can leave the port
    # in TIME_WAIT for a short while; without SO_REUSEADDR that shows up as
    # "Address already in use" even though nothing is actually still
    # listening (confirmed real occurrence: backend.rs restarted this process
    # right after killing the old one and hit exactly this). This is the
    # standard fix, not a workaround for a real conflict -- a *genuinely*
    # still-alive process on the port still fails to bind either way.
    allow_reuse_address = True


def main():
    global UPSTREAM
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--upstream", default=UPSTREAM, help="mlx_lm.server base URL, e.g. http://127.0.0.1:11440")
    parser.add_argument("--host", default="127.0.0.1")
    args = parser.parse_args()
    UPSTREAM = args.upstream

    try:
        server = ReusableThreadingHTTPServer((args.host, args.port), BridgeHandler)
    except OSError as e:
        # A clean one-line message beats a raw traceback in the log viewer --
        # backend.rs's readiness poll already turns a bind failure into a
        # proper error for the user; this is just for whoever is staring at
        # backend logs trying to figure out why.
        print(f"[responses_bridge] failed to bind {args.host}:{args.port}: {e}", flush=True, file=sys.stderr)
        sys.exit(1)
    print(f"[responses_bridge] listening on {args.host}:{args.port}, upstream={UPSTREAM}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
