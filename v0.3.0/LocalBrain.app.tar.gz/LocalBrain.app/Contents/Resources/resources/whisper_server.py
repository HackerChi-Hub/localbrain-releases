#!/usr/bin/env python3
"""Minimal OpenAI-compatible Whisper transcription server (stdlib + mlx_whisper).

Endpoints:
  GET  /health                      -> 200 {"status":"ok"}  (readiness probe)
  POST /v1/audio/transcriptions     -> {"text": ..., "segments": [...]}
       accepts multipart/form-data with a `file` field (OpenAI-style),
       or JSON {"path": "/local/file.wav", "language": "en"} for local files.

Only dependency beyond the stdlib is `mlx_whisper` (pulls in mlx).
The model is loaded lazily on the first transcription request.
"""
import argparse
import json
import os
import sys
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MODEL_PATH = None


def transcribe(audio_path, language=None):
    import mlx_whisper  # imported lazily so /health is up immediately

    kwargs = {}
    if language:
        kwargs["language"] = language
    return mlx_whisper.transcribe(audio_path, path_or_hf_repo=MODEL_PATH, **kwargs)


def parse_multipart(raw, boundary):
    """Extract the `file` payload (and optional `language`) from a multipart body."""
    delim = ("--" + boundary).encode()
    audio = None
    suffix = ".wav"
    language = None
    for part in raw.split(delim):
        if not part or part in (b"--\r\n", b"--", b"\r\n"):
            continue
        if b"\r\n\r\n" not in part:
            continue
        head, body = part.split(b"\r\n\r\n", 1)
        if body.endswith(b"\r\n"):
            body = body[:-2]
        head_text = head.decode("utf-8", "ignore")
        disposition = next(
            (l for l in head_text.split("\r\n") if l.lower().startswith("content-disposition")),
            "",
        )
        name = None
        filename = None
        for token in disposition.split(";"):
            token = token.strip()
            if token.startswith("name="):
                name = token.split("=", 1)[1].strip('"')
            elif token.startswith("filename="):
                filename = token.split("=", 1)[1].strip('"')
        if name == "file" or filename:
            audio = body
            if filename and "." in filename:
                suffix = "." + filename.rsplit(".", 1)[1]
        elif name == "language":
            language = body.decode("utf-8", "ignore").strip() or None
    return audio, suffix, language


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/health") or self.path.startswith("/v1/models"):
            self._send(200, {"status": "ok", "model": MODEL_PATH})
        else:
            self._send(404, {"error": "not found"})

    def do_POST(self):
        if not self.path.startswith("/v1/audio/transcriptions"):
            self._send(404, {"error": "not found"})
            return

        ctype = self.headers.get("Content-Type", "")
        length = int(self.headers.get("Content-Length", 0) or 0)
        raw = self.rfile.read(length) if length else b""

        # JSON path mode (convenience for local files)
        if ctype.startswith("application/json"):
            try:
                data = json.loads(raw.decode("utf-8"))
            except json.JSONDecodeError:
                self._send(400, {"error": "invalid JSON body"})
                return
            try:
                path = data.get("path")
                if not path or not os.path.exists(path):
                    self._send(400, {"error": "path missing or not found"})
                    return
                result = transcribe(path, data.get("language"))
                self._send(200, {"text": result.get("text", ""), "segments": result.get("segments", [])})
            except Exception as exc:  # noqa: BLE001
                self._send(500, {"error": str(exc)})
            return

        # multipart file upload (OpenAI-style)
        if "multipart/form-data" in ctype and "boundary=" in ctype:
            boundary = ctype.split("boundary=", 1)[1].strip()
            audio, suffix, language = parse_multipart(raw, boundary)
            if audio is None:
                self._send(400, {"error": "no audio file provided"})
                return
            tmp = None
            try:
                with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
                    f.write(audio)
                    tmp = f.name
                result = transcribe(tmp, language)
                self._send(200, {"text": result.get("text", ""), "segments": result.get("segments", [])})
            except Exception as exc:  # noqa: BLE001
                self._send(500, {"error": str(exc)})
            finally:
                if tmp and os.path.exists(tmp):
                    os.unlink(tmp)
            return

        self._send(400, {"error": "unsupported content type"})

    def log_message(self, fmt, *args):
        # route access logs to stderr (captured by LocalBrain)
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))
        sys.stderr.flush()


def main():
    global MODEL_PATH
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="local MLX whisper model dir or HF repo")
    ap.add_argument("--port", type=int, default=11435)
    ap.add_argument("--host", default="127.0.0.1")
    args = ap.parse_args()

    MODEL_PATH = args.model
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    sys.stderr.write(f"whisper_server listening on {args.host}:{args.port} model={MODEL_PATH}\n")
    sys.stderr.flush()
    server.serve_forever()


if __name__ == "__main__":
    main()
