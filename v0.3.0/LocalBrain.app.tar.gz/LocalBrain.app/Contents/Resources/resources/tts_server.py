#!/usr/bin/env python3
"""Minimal OpenAI-compatible TTS server (stdlib) backed by mlx-audio.

Endpoints:
  GET  /health               -> 200 {"status":"ok"}  (readiness probe)
  POST /v1/audio/speech      -> raw WAV bytes (OpenAI-style). Body (JSON):
       { "input": "...text...", "speed": 1.0, "instruct": "...", "voice": "..." }

All machine-specific bits are CLI args (nothing hardcoded), so the backend is
portable: point --mlx-audio-python / --model / --ref-audio at your own install.

It shells out to mlx-audio's `generate_audio` exactly like the user's TTS-Server
engine, but every path is configurable.
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

CFG = {}  # populated from CLI args in main()


def synthesize(text, out_prefix, speed=1.0, instruct=None):
    """Call mlx-audio generate_audio in its own interpreter; return path to WAV."""
    args = {
        "text": text,
        "model": CFG["model"],
        "file_prefix": out_prefix,
        "audio_format": "wav",
        "verbose": False,
        "speed": speed,
        "lang_code": CFG["lang"],
        "temperature": CFG["temperature"],
    }
    if CFG.get("ref_audio"):
        args["ref_audio"] = CFG["ref_audio"]
    if CFG.get("ref_text"):
        args["ref_text"] = CFG["ref_text"]
    if instruct:
        args["instruct"] = instruct

    lines = ["import sys, json"]
    if CFG.get("mlx_audio_site"):
        lines.append(f"sys.path.insert(0, {CFG['mlx_audio_site']!r})")
    lines.append("from mlx_audio.tts.generate import generate_audio")
    lines.append(f"generate_audio(**json.loads({json.dumps(args)!r}))")
    script = "\n".join(lines) + "\n"

    result = subprocess.run(
        [CFG["mlx_audio_python"], "-c", script],
        capture_output=True,
        text=True,
        timeout=600,
    )
    if result.returncode != 0:
        raise RuntimeError(f"mlx-audio error: {result.stderr[-600:]}")

    produced = out_prefix + "_000.wav"
    if os.path.exists(produced):
        return produced
    if os.path.exists(out_prefix):
        return out_prefix
    raise RuntimeError("mlx-audio produced no output file")


class Handler(BaseHTTPRequestHandler):
    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/health") or self.path.startswith("/v1/models"):
            self._json(200, {"status": "ok", "model": CFG["model"]})
        else:
            self._json(404, {"error": "not found"})

    def do_POST(self):
        if not self.path.startswith("/v1/audio/speech"):
            self._json(404, {"error": "not found"})
            return
        length = int(self.headers.get("Content-Length", 0) or 0)
        raw = self.rfile.read(length) if length else b""
        try:
            data = json.loads(raw.decode("utf-8")) if raw else {}
        except json.JSONDecodeError:
            self._json(400, {"error": "invalid JSON body"})
            return
        text = (data.get("input") or data.get("text") or "").strip()
        if not text:
            self._json(400, {"error": "missing 'input' text"})
            return
        # speed 转换放在 try 内：非法值返回 400 而非崩连接
        try:
            speed = float(data.get("speed", 1.0))
        except (TypeError, ValueError):
            self._json(400, {"error": "'speed' must be numeric"})
            return
        instruct = data.get("instruct")

        os.makedirs(CFG["out_dir"], exist_ok=True)
        # NamedTemporaryFile 会留一个空 stub（实际输出是 prefix_000.wav），用完必须删
        fd, prefix = tempfile.mkstemp(dir=CFG["out_dir"], suffix="")
        os.close(fd)
        wav = None
        try:
            wav = synthesize(text, prefix, speed=speed, instruct=instruct)
            with open(wav, "rb") as fh:
                audio = fh.read()
        except Exception as exc:  # noqa: BLE001
            self._json(500, {"error": str(exc)})
            return
        finally:
            # 清理空 stub（实际 WAV 文件 wav 保留）
            if os.path.exists(prefix):
                try:
                    os.remove(prefix)
                except OSError:
                    pass

        self.send_response(200)
        self.send_header("Content-Type", "audio/wav")
        self.send_header("Content-Length", str(len(audio)))
        self.send_header("X-Output-Path", wav)
        self.end_headers()
        self.wfile.write(audio)

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))
        sys.stderr.flush()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="TTS model dir (clone or voice-design)")
    ap.add_argument("--mlx-audio-python", required=True, help="python with mlx_audio installed")
    ap.add_argument("--mlx-audio-site", default="", help="optional extra sys.path for mlx_audio")
    ap.add_argument("--ref-audio", default="", help="reference voice wav (clone mode)")
    ap.add_argument("--ref-text", default="", help="transcript of the reference voice")
    ap.add_argument("--lang", default="zh")
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--out-dir", default=tempfile.gettempdir())
    ap.add_argument("--port", type=int, default=11436)
    ap.add_argument("--host", default="127.0.0.1")
    a = ap.parse_args()

    CFG.update(
        {
            "model": a.model,
            "mlx_audio_python": a.mlx_audio_python,
            "mlx_audio_site": a.mlx_audio_site,
            "ref_audio": a.ref_audio,
            "ref_text": a.ref_text,
            "lang": a.lang,
            "temperature": a.temperature,
            "out_dir": a.out_dir,
        }
    )

    server = ThreadingHTTPServer((a.host, a.port), Handler)
    sys.stderr.write(f"tts_server listening on {a.host}:{a.port} model={a.model}\n")
    sys.stderr.flush()
    server.serve_forever()


if __name__ == "__main__":
    main()
