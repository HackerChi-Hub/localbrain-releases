#!/usr/bin/env python3
"""LocalBrain MCP server — exposes local multi-modal backends as MCP tools.

Speaks the Model Context Protocol over stdio (newline-delimited JSON-RPC 2.0),
so any MCP client (Claude Code, Codex, opencode, …) can call local capabilities
that cloud LLM runners don't offer — starting with on-device speech-to-text.

Stdlib only. It reaches LocalBrain's backends over their local HTTP ports:
  Whisper transcription -> http://127.0.0.1:$LOCALBRAIN_WHISPER_PORT/v1/audio/transcriptions

The backend must be started from the LocalBrain app first.
"""
import json
import os
import sys
import urllib.request

PROTOCOL_VERSION = "2025-06-18"
SERVER_NAME = "localbrain"
SERVER_VERSION = "0.1.0"

WHISPER_PORT = int(os.environ.get("LOCALBRAIN_WHISPER_PORT", "11435"))
TTS_PORT = int(os.environ.get("LOCALBRAIN_TTS_PORT", "11436"))
IMAGE_PORT = int(os.environ.get("LOCALBRAIN_IMAGE_PORT", "11437"))
VIDEO_PORT = int(os.environ.get("LOCALBRAIN_VIDEO_PORT", "11438"))

TOOLS = [
    {
        "name": "transcribe_audio",
        "description": (
            "Transcribe a local audio/video file to text using LocalBrain's on-device "
            "Whisper (MLX) backend. Fully local, no cloud, no API key. The Whisper backend "
            "must be running in the LocalBrain app."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Absolute path to a local audio or video file.",
                },
                "language": {
                    "type": "string",
                    "description": "Optional ISO language hint, e.g. 'en' or 'zh'.",
                },
            },
            "required": ["path"],
        },
    },
    {
        "name": "text_to_speech",
        "description": (
            "Synthesize speech from text using LocalBrain's on-device TTS (mlx-audio) "
            "backend, and return the path to the generated WAV file. Fully local, no cloud. "
            "The TTS backend must be running in the LocalBrain app."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "The text to speak.",
                },
                "instruct": {
                    "type": "string",
                    "description": "Optional voice-design instruction, e.g. 'a calm female voice'.",
                },
            },
            "required": ["text"],
        },
    },
    {
        "name": "generate_image",
        "description": (
            "Generate an image from a text prompt using LocalBrain's on-device image "
            "backend (Z-Image), and return the path to the PNG. Fully local, no cloud. "
            "The image backend must be running in the LocalBrain app."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "The image description."},
                "size": {
                    "type": "string",
                    "description": "landscape | portrait | square | wide | WxH (default landscape).",
                },
                "negative_prompt": {"type": "string", "description": "Optional negative prompt."},
            },
            "required": ["prompt"],
        },
    },
    {
        "name": "generate_video",
        "description": (
            "Generate a short video from a text prompt using LocalBrain's on-device video "
            "backend (LTX-2.3), and return the path to the MP4. Fully local, no cloud. Slow "
            "(~2-3 min). The video backend must be running in the LocalBrain app."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "The video description."},
                "num_frames": {"type": "integer", "description": "Frame count (default 65)."},
                "image": {
                    "type": "string",
                    "description": "Optional first-frame image path (image-to-video).",
                },
            },
            "required": ["prompt"],
        },
    },
]


def http_post_json(url, payload, timeout=600):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=data, headers={"Content-Type": "application/json"}, method="POST"
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def tool_transcribe_audio(args):
    path = args.get("path")
    if not path or not os.path.exists(path):
        return {"isError": True, "text": f"file not found: {path!r}"}
    url = f"http://127.0.0.1:{WHISPER_PORT}/v1/audio/transcriptions"
    payload = {"path": path}
    if args.get("language"):
        payload["language"] = args["language"]
    try:
        result = http_post_json(url, payload)
    except Exception as exc:  # noqa: BLE001
        return {
            "isError": True,
            "text": (
                f"Could not reach Whisper backend on port {WHISPER_PORT} ({exc}). "
                "Start the Whisper backend in LocalBrain first."
            ),
        }
    return {"isError": False, "text": result.get("text", "")}


def http_post_audio(url, payload, timeout=600):
    """POST JSON, return (body_bytes, x_output_path_header)."""
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=data, headers={"Content-Type": "application/json"}, method="POST"
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read(), resp.headers.get("X-Output-Path")


def tool_text_to_speech(args):
    text = (args.get("text") or "").strip()
    if not text:
        return {"isError": True, "text": "missing 'text'"}
    url = f"http://127.0.0.1:{TTS_PORT}/v1/audio/speech"
    payload = {"input": text}
    if args.get("instruct"):
        payload["instruct"] = args["instruct"]
    try:
        body, out_path = http_post_audio(url, payload)
    except Exception as exc:  # noqa: BLE001
        return {
            "isError": True,
            "text": (
                f"Could not reach TTS backend on port {TTS_PORT} ({exc}). "
                "Start the TTS backend in LocalBrain first."
            ),
        }
    if out_path and os.path.exists(out_path):
        return {"isError": False, "text": f"Speech written to: {out_path}"}
    import tempfile

    fd, path = tempfile.mkstemp(suffix=".wav")
    with os.fdopen(fd, "wb") as fh:
        fh.write(body)
    return {"isError": False, "text": f"Speech written to: {path}"}


def tool_generate_image(args):
    prompt = (args.get("prompt") or "").strip()
    if not prompt:
        return {"isError": True, "text": "missing 'prompt'"}
    url = f"http://127.0.0.1:{IMAGE_PORT}/v1/images/generations"
    payload = {"prompt": prompt}
    if args.get("size"):
        payload["size"] = args["size"]
    if args.get("negative_prompt"):
        payload["negative_prompt"] = args["negative_prompt"]
    try:
        res = http_post_json(url, payload)
    except Exception as exc:  # noqa: BLE001
        return {
            "isError": True,
            "text": (
                f"Could not reach image backend on port {IMAGE_PORT} ({exc}). "
                "Start the image backend in LocalBrain first."
            ),
        }
    data = res.get("data") or []
    if data and data[0].get("path"):
        return {"isError": False, "text": f"Image written to: {data[0]['path']}"}
    return {"isError": True, "text": f"unexpected response: {res}"}


def tool_generate_video(args):
    prompt = (args.get("prompt") or "").strip()
    if not prompt:
        return {"isError": True, "text": "missing 'prompt'"}
    url = f"http://127.0.0.1:{VIDEO_PORT}/v1/video/generations"
    payload = {"prompt": prompt}
    if args.get("num_frames"):
        payload["num_frames"] = args["num_frames"]
    if args.get("image"):
        payload["image"] = args["image"]
    try:
        res = http_post_json(url, payload, timeout=1800)
    except Exception as exc:  # noqa: BLE001
        return {
            "isError": True,
            "text": (
                f"Could not reach video backend on port {VIDEO_PORT} ({exc}). "
                "Start the video backend in LocalBrain first."
            ),
        }
    data = res.get("data") or []
    if data and data[0].get("path"):
        return {"isError": False, "text": f"Video written to: {data[0]['path']}"}
    return {"isError": True, "text": f"unexpected response: {res}"}


TOOL_IMPLS = {
    "transcribe_audio": tool_transcribe_audio,
    "text_to_speech": tool_text_to_speech,
    "generate_image": tool_generate_image,
    "generate_video": tool_generate_video,
}


def send(message):
    sys.stdout.write(json.dumps(message) + "\n")
    sys.stdout.flush()


def reply(req_id, result):
    send({"jsonrpc": "2.0", "id": req_id, "result": result})


def reply_error(req_id, code, message):
    send({"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}})


def handle(req):
    method = req.get("method")
    req_id = req.get("id")

    # notifications (no id) — never reply
    if req_id is None:
        return

    if method == "initialize":
        client_proto = (req.get("params") or {}).get("protocolVersion") or PROTOCOL_VERSION
        reply(
            req_id,
            {
                "protocolVersion": client_proto,
                "capabilities": {"tools": {}},
                "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
            },
        )
    elif method == "ping":
        reply(req_id, {})
    elif method == "tools/list":
        reply(req_id, {"tools": TOOLS})
    elif method == "tools/call":
        params = req.get("params") or {}
        name = params.get("name")
        impl = TOOL_IMPLS.get(name)
        if impl is None:
            reply_error(req_id, -32602, f"unknown tool: {name}")
            return
        out = impl(params.get("arguments") or {})
        reply(
            req_id,
            {
                "content": [{"type": "text", "text": out["text"]}],
                "isError": out.get("isError", False),
            },
        )
    else:
        reply_error(req_id, -32601, f"method not found: {method}")


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            continue
        try:
            handle(req)
        except Exception as exc:  # noqa: BLE001
            if isinstance(req, dict) and req.get("id") is not None:
                reply_error(req["id"], -32603, f"internal error: {exc}")


if __name__ == "__main__":
    main()
