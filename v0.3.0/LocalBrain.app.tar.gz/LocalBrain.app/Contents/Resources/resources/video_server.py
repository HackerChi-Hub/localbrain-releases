#!/usr/bin/env python3
"""Minimal video-generation server (stdlib) backed by mlx-video (LTX-2.3).

Endpoints:
  GET  /health                  -> 200 (readiness; the model loads per request)
  POST /v1/video/generations    -> {"created":..., "data":[{"path": "<mp4>"}]}
       body: { "prompt": "...", "num_frames": 65, "width": 1280, "height": 720,
               "seed": 42, "pipeline": "distilled", "image": "<first-frame.jpg>" }

All machine-specific bits are CLI args, so the backend is portable: point
--ltx-python / --model-dir / --text-encoder at your own install. LTX runs as a
subprocess per request (the model loads each call, ~2-3 min), matching mlx-video.
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

CFG = {}


def generate(prompt, params, image=None):
    out = os.path.join(CFG["out_dir"], f"vid_{int(time.time() * 1000)}.mp4")
    os.makedirs(CFG["out_dir"], exist_ok=True)
    cmd = [
        CFG["ltx_python"],
        "-m", "mlx_video.models.ltx_2.generate",
        "--prompt", prompt,
        "--model-repo", CFG["model_dir"],
        "--text-encoder-repo", CFG["text_encoder"],
        "--num-frames", str(params["num_frames"]),
        "--height", str(params["height"]),
        "--width", str(params["width"]),
        "--seed", str(params["seed"]),
        "--pipeline", params["pipeline"],
        "--output-path", out,
    ]
    if image:
        cmd.extend(["--image", image])

    env = os.environ.copy()
    env["HF_HUB_OFFLINE"] = "1"
    proc = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        env=env,
        timeout=CFG["timeout"],
        cwd=CFG["cwd"],
    )
    if proc.returncode != 0:
        raise RuntimeError(f"mlx-video error: {proc.stderr[-800:]}")
    if not os.path.exists(out):
        raise RuntimeError("mlx-video produced no output file")
    return out


class Handler(BaseHTTPRequestHandler):
    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/health") or self.path.startswith("/v1/models"):
            self._json(200, {"status": "ok", "model": CFG["model_dir"]})
        else:
            self._json(404, {"error": "not found"})

    def do_POST(self):
        if not self.path.startswith("/v1/video/generations"):
            self._json(404, {"error": "not found"})
            return
        length = int(self.headers.get("Content-Length", 0) or 0)
        raw = self.rfile.read(length) if length else b""
        try:
            data = json.loads(raw.decode("utf-8")) if raw else {}
        except json.JSONDecodeError:
            self._json(400, {"error": "invalid JSON body"})
            return
        prompt = (data.get("prompt") or "").strip()
        if not prompt:
            self._json(400, {"error": "missing 'prompt'"})
            return
        # 首帧图存在性检查：避免浪费几分钟的模型加载才发现路径错
        image = data.get("image")
        if image and not os.path.exists(image):
            self._json(400, {"error": f"image not found: {image}"})
            return
        # 参数转换放在 try 内：非法值返回 400。
        # seed 用 is None 区分「未传」与「传了 0」——否则 int(0 or 42) 永远是 42。
        try:
            params = {
                "num_frames": int(data["num_frames"]) if data.get("num_frames") is not None else CFG["num_frames"],
                "width": int(data["width"]) if data.get("width") is not None else CFG["width"],
                "height": int(data["height"]) if data.get("height") is not None else CFG["height"],
                "pipeline": data.get("pipeline") or CFG["pipeline"],
                "seed": 42 if data.get("seed") is None else int(data["seed"]),
            }
        except (TypeError, ValueError):
            self._json(400, {"error": "num_frames/width/height/seed must be integers"})
            return
        try:
            out = generate(prompt, params, image=image)
        except Exception as exc:  # noqa: BLE001
            self._json(500, {"error": str(exc)})
            return
        self._json(200, {"created": int(time.time()), "data": [{"path": out}]})

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))
        sys.stderr.flush()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ltx-python", required=True, help="python with mlx_video installed")
    ap.add_argument("--model-dir", required=True, help="LTX model repo dir")
    ap.add_argument("--text-encoder", required=True, help="text encoder repo dir")
    ap.add_argument("--pipeline", default="distilled")
    ap.add_argument("--num-frames", type=int, default=65)
    ap.add_argument("--width", type=int, default=1280)
    ap.add_argument("--height", type=int, default=720)
    ap.add_argument("--timeout", type=int, default=1200)
    ap.add_argument("--cwd", default="")
    ap.add_argument("--out-dir", default=os.path.join(tempfile.gettempdir(), "localbrain_videos"))
    ap.add_argument("--port", type=int, default=11438)
    ap.add_argument("--host", default="127.0.0.1")
    a = ap.parse_args()

    CFG.update(
        {
            "ltx_python": a.ltx_python,
            "model_dir": a.model_dir,
            "text_encoder": a.text_encoder,
            "pipeline": a.pipeline,
            "num_frames": a.num_frames,
            "width": a.width,
            "height": a.height,
            "timeout": a.timeout,
            "cwd": a.cwd or os.path.dirname(os.path.dirname(os.path.dirname(a.ltx_python))),
            "out_dir": a.out_dir,
        }
    )

    server = ThreadingHTTPServer((a.host, a.port), Handler)
    sys.stderr.write(f"video_server listening on {a.host}:{a.port} model={a.model_dir}\n")
    sys.stderr.flush()
    server.serve_forever()


if __name__ == "__main__":
    main()
